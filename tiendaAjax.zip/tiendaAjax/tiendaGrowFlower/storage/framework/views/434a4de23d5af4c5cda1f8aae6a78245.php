<link rel="stylesheet" href="assets/css/styles.css">


  <div id="myModal" class="modal">
    <div class="modal-content">
        <h2>Crear productos</h2> 
        <span class="close">&times;</span>

        <input class="input" type="number" placeholder="Categoria" name="idcategoria" id="idcategoria"><br>
        <input class="input" type="text" placeholder="Nombre" name="nombre" id="nombre"><br>
      <input class="input" type="number" placeholder="Precio" name="precio" id="precio"><br>
      <input class="input" type="text" placeholder="Descripcion" name="descripcion" id="descripcion"><br>
      <!--<input class="input" type="text" placeholder="foto" name="foto"><br>-->
        
      <button id="saveBtn">Guardar</button>
    </div>
     
  </div>
  <div id="editModal" class="modal">
  <div class="modal-content">
    <input class="input" type="number" placeholder="Categoria" name="categoriaEdit" id="idcategoria"><br>
        <input class="input" type="text" placeholder="Nombre" name="nombreEdit" id="nombre"><br>
      <input class="input" type="number" placeholder="Precio" name="precioEdit" id="precio"><br>
      <input class="input" type="text" placeholder="Descripcion" name="descripcionEdit" id="descripcion"><br>
      
    <button id="guardarCambios"></button>
    </div>
</div>


  <div id="myModal2" class="modal2">
    <div class="modal-content2">
        <h2>Crear productos</h2> 
        <span class="close2">&times;</span>
      
        <input class="input" type="text" placeholder="Nombre" name="categoria" id="categoria"><br>
     
      <button id="saveBtn2">Guardar</button>
    </div>
  </div>
  <div id="content">
    
  </div>
  
<?php echo $__env->make('app.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/tiendaAjax/tiendaGrowFlower/resources/views/backend/index.blade.php ENDPATH**/ ?>