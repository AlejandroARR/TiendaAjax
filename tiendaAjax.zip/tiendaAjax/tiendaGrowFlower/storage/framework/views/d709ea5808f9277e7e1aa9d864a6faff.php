<link rel="stylesheet" href="assets/css/styles.css">
<!--<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">-->

  <div id="myModal" class="modal">
    <div class="modal-content">
        <h2>Crear productos</h2> 
        <span class="close">&times;</span>

        <input class="input" type="number" placeholder="Categoria" name="idcategoria" id="idcategoria"><br>
        <input class="input" type="text" placeholder="Nombre" name="nombre" id="nombre"><br>
      <input class="input" type="number" placeholder="Precio" name="precio" id="precio"><br>
      <input class="input" type="text" placeholder="Descripcion" name="descripcion" id="descripcion"><br>
      <!--<input class="input" type="text" placeholder="foto" name="foto"><br>-->
        
      <button id="saveBtn">Guardar</button>
    </div>
     
  </div>
  


  <div id="myModal2" class="modal2">
    <div class="modal-content2">
        <h2>Crear productos</h2> 
        <span class="close2">&times;</span>
      
        <input class="input" type="text" placeholder="Nombre" name="categoria" id="categoria"><br>
     
      <button id="saveBtn2">Guardar</button>
    </div>
  </div>
  <div id="content">
    
  </div>
  
  
  <div id="editModal" class="modal">
    <label for="">EDITA ESTE PRODUCTO</label>
  <div class="modal-content" id="ModalParaEditar">
      <!--<label for="">Categoria</label>-->
    <!--<input class="input" type="number" placeholder="Categoria" name="categoriaEdit" id="categoriaEdit"><br>-->
      <label for="">Nombre del producto</label>
      <input class="input" type="text" placeholder="Nombre" name="nombreEdit" id="nombreEdit"><br>
      <label for="">Precio del producto</label>
      <input class="input" type="number" placeholder="Precio" name="precioEdit" id="precioEdit"><br>
      <label for="">Descripcion del producto</label>
      <input class="input" type="text" placeholder="Descripcion" name="descripcionEdit" id="descripcionEdit"><br>
      
    <button id="guardarCambios"></button>
    </div>
</div>



<?php echo $__env->make('app.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/tiendaAjax/tiendaGrowFlower/resources/views//backend/index.blade.php ENDPATH**/ ?>