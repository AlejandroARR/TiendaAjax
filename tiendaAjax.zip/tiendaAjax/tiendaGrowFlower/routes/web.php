<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductosController;
use App\Http\Controllers\gestionController;
use App\Http\Controllers\gestionCatgController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('/front/index');
});

Route::get('productos', [ProductosController::class, 'index'])->name('productos.index');

Route::get('/backend',function(){
  return view('/backend/index'); 
});
Route::get('/backendControll',[gestionController::class,'index'])->name('backend.index');
Route::post('/backendControll',[gestionController::class,'store'])->name('backend.store');
Route::put('producto/{id}', [ProductosController::class, 'update'])->name('productos.update');   
Route::delete('/productoDelete', [gestionController::class, 'destroy'])->name('producto.destroy');

Route::get('/backendCatgControll',[gestionCatgController::class,'index'])->name('backend.index');
Route::post('/backendCatg',[gestionCatgController::class,'store'])->name('backend.store');
Route::delete('/categoriaDelete', [gestionCatgController::class, 'destroy'])->name('categoria.destroy');



Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
