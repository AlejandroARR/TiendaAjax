<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Categorias;
class gestionCatgController extends Controller
{
   function index() {
        $categorias = Categorias::all();
        
        // Reponde un array a pelo
        //return response()->json($paises);
        // Responde con un array pero con un atributo asi podemos identificar la respuesta
        return response()->json(['categorias' => $categorias]);
    }
     function store(Request $request) {
        
        try {
                $categoria = new Categorias($request->all());
         
                $categoria->save();
              $respuesta = [
                                'result' => 1,
                                'message' => 'Categoria insertado correctamente.',
                                'categoria' => Categorias::all(),
                                
                            ];
            } catch(\Exception $e) {
                $respuesta = ['result' => -2, 'message' => $e];
            }
            return response()->json($respuesta);
     }
      
      public function destroy(Request $request) {
    try {
        $data = $request->json()->all(); // Obtener los datos del cuerpo de la solicitud
        $id = $data['id']; // Obtener el ID de la categoría
        $nombre = $data['nombre']; // Obtener el nombre de la categoría

        // Utiliza el ID y el nombre para buscar y eliminar la categoría...
        $categoria = Categorias::where('id', $id)->where('nombre', $nombre)->first();

        if ($categoria) {
            $categoria->delete();
            $respuesta = [
                'result' => 1,
                'message' => 'Categoría eliminada correctamente.',
                'categorias' => Categorias::all()
            ];
        } else {
            $respuesta = [
                'result' => -1,
                'message' => 'La categoría no existe.'
            ];
        }
    } catch(\Exception $e) {
        $respuesta = [
            'result' => -2,
            'message' => $e->getMessage()
        ];
    }

    return response()->json($respuesta);
}



}
