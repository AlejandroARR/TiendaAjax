<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class categoriasController extends Controller
{
    function index() {
        $productos = Productos::all();
        
        // Reponde un array a pelo
        //return response()->json($paises);
        // Responde con un array pero con un atributo asi podemos identificar la respuesta
        return response()->json(['producto' => $productos]);
    }
     function store(Request $request) {
       
        try {
                $producto = new Productos($request->all());
         
                $producto->save();
              $respuesta = [
                                'result' => 1,
                                'message' => 'País insertado correctamente.',
                                'paises' => Productos::all()
                            ];
            } catch(\Exception $e) {
                $respuesta = ['result' => -2, 'message' => $e];
            }
            return response()->json($respuesta);
     }
}
