 /* global bootstrap fetch */
(() => {
    'use strict'
    
 
    const csrf = document.querySelector('meta[name="csrf-token"]')['content'];
    const url = document.querySelector('meta[name="url-base"]')['content'];
   
    
    
     document.addEventListener("DOMContentLoaded", function(event) {
         console.log("hola");
         peticionAjax();
          console.log("hola");
     })
     
     
     function peticionAjax() {
        fetch(url + '/productos')
        .then(response => response.json())
        .then(data => {
            console.log(data);
            mostrarProductos(data.producto);
        })
        .catch(error => console.error("Error:", error ));
    }
    
     let total=0;
   function mostrarProductos(productos){
        const contentDiv = document.getElementById("contenido");
        console.log(productos);
        productos.forEach(producto =>{
            let divCol = document.createElement('div');
            divCol.className = 'col d-flex justify-content-center mt-3';
            
            let card = document.createElement('div');
            card.className = 'card shadow w-75';
            card.setAttribute('style', 'width: 18rem');
            
            divCol.appendChild(card);
            
            let img = document.createElement('img');
            img.className = 'card-img-top';
            img.setAttribute('alt', 'IMG not fount');
            
            let cardBody = document.createElement('div');
            cardBody.className = 'card-body d-flex justify-content-between flex-column';
            
            card.appendChild(img);
            card.appendChild(cardBody);
            
            
            let h5 = document.createElement('h5');
            h5.className = 'card-title';
            h5.innerHTML = `${producto.nombre}`;
            
            let p = document.createElement('p');
            p.className = 'card-text mt-2';
            p.innerHTML = `${producto.descripcion}`;
            let precio = document.createElement('p');
            precio.className = 'card-text mt-2';
            precio.innerHTML = `${producto.precio}`+'\u20AC';
            
            let a = document.createElement('a');
            a.className = 'btn btn-outline-success mt-2 ';
            a.innerHTML = 'Añadir';
           
            a.onclick=function(){
                let cesta = document.getElementById("cesta");
                let object= document.createElement("div");
                let h1=document.createElement("h4");
                let h2=document.createElement("h6");
                let h3=document.createElement("h6");
                let totales=document.getElementById("totales");
                let totalCesta=document.getElementById("total");
                object.id="object";
                h1.innerHTML=producto.nombre;
                h1.id="h3";
                h2.innerHTML=producto.descripcion;
                h2.id="h2";
                h3.innerHTML=producto.precio +" €";
                h3.id="h5";
                
                total=total+producto.precio;
                totales.innerHTML=total;
                object.appendChild(h1);
                object.appendChild(h2);
                object.appendChild(h3);
                cesta.appendChild(object);
                totalCesta.appendChild(totales);
            }
            
            
            cardBody.appendChild(h5);
            cardBody.appendChild(p);
            cardBody.appendChild(precio);
            cardBody.appendChild(a);
            
            contentDiv.appendChild(divCol);    
        });
    }
     
     
    //  function llamadaAjax(data) {
    //     fetch(url + '/pais', {
    //       method: 'POST',
    //       headers: {
    //         'Content-Type': 'application/json',
    //         'Accept': 'application/json',
    //         'X-CSRF-TOKEN': csrf
    //       }
    //     })
    //  }
     //PAGINACION
     document.getElementById("num_registros").addEventListener('change',getData) 
     
     function getData(){
         
     }
})()