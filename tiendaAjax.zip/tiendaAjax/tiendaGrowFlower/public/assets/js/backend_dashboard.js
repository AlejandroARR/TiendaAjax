 /* global bootstrap fetch */
(() => {
    'use strict'
   
    const csrf = document.querySelector('meta[name="csrf-token"]')['content'];
    const url = document.querySelector('meta[name="url-base"]')['content'];
     
     let containerArea= document.getElementById("containerArea");
     let nombreCreate = document.getElementById('nombre');
    let categoriaCreate = document.getElementById('idcategoria');
    let descripcionCreate = document.getElementById('descripcion');
    let precioCreate = document.getElementById('precio');
    
    function peticionAjax() {
        fetch(url + '/backendControll')
        .then(response => response.json())
        .then(data => {
            console.log(data);
            mostrarProductos(data);
        })
        .catch(error => console.error("Error:", error));
    }
     
       
     function peticionAjaxCtg() {
        fetch(url + '/backendCatgControll')
        .then(response => response.json())
        .then(data => {
            console.log(data);
             mostrarCatg(data);
        })
        .catch(error => console.error("Error:", error));
    }
     
     
     var modal2= document.getElementById("myModal2");
      var spanClose2 = document.getElementsByClassName("close2")[0];
      let btn_categorias= document.getElementById("btn_categorias");
      let categoria = document.getElementById("categoria");
      var btnSave2=document.getElementById("saveBtn2");
       //Btn Crear Categorias
          btn_categorias.onclick=function(){
              
             modal2.style.display="block";
             
     }
    btnSave2.onclick = function() {
        
    let valor_categoria = {
        nombre: categoria.value
    };
   llamadaAjaxCat(valor_categoria);
};

    //Obtener elementos del DOM  
    
    modal2.style.display="none";
    
    
    //Btn para cerrar modal
    spanClose2.onclick= function() {
  modal2.style.display = "none";
}
 function llamadaAjaxCat(data) {
          console.log("hola");
        fetch(url + '/backendCatg', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': csrf
            },
            body: JSON.stringify(data),
            
        })
        
            .then(response => response.json())
            .then(data => {
                
                if (data.result > 0) {
                    console.log('Categoria correctamente insertado');
                    // Aquí puedes realizar otras acciones después de insertar el país correctamente
                } else {
                    console.log('Error al insertar la categoria');
                    // Aquí puedes manejar el caso de error, si deseas hacer algo específico
                }
            })
            .catch(error => {
                console.log("Error:", error);
            });
    }





    
    
    //  Btn Crear productos
     
   
     
     // Obtener elementos del DOM
    var modal = document.getElementById("myModal");
    var btnOpenModal = document.getElementById("btn_productos");
    var btnSave = document.getElementById("saveBtn");
    var spanClose = document.getElementsByClassName("close")[0];
    
    // Función para abrir el modal
    btnOpenModal.onclick = function() {
      modal.style.display = "block";
    }
    
    // Función para cerrar el modal al hacer clic en la 'x'
    spanClose.onclick = function() {
      modal.style.display = "none";
    }

    
    
    // Función para guardar los datos del modal
    btnSave.onclick = function() {
    
    let data = {
                  nombre: nombreCreate.value,
                  idcategoria: categoriaCreate.value,
                  descripcion: descripcionCreate.value,
                  precio: precioCreate.value,
                };
                //validar en js, nos lo saltamnos
                llamadaAjax(data);
        
       modal.style.display = "none";
    }

     
    //  
     
      function llamadaAjax(data) {
          
        fetch(url + '/backendControll', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': csrf
            },
            body: JSON.stringify(data),
            
        })
        
            .then(response => response.json())
            .then(data => {
                console.log(data);
                if (data.result > 0) {
                    console.log('País correctamente insertado');
                    // Aquí puedes realizar otras acciones después de insertar el país correctamente
                } else {
                    console.log('Error al insertar el país');
                    // Aquí puedes manejar el caso de error, si deseas hacer algo específico
                }
            })
            .catch(error => {
                console.log("Error:", error);
            });
    }
    
    
     //Mostrar categorias
     var boton_categorias = document.getElementById("boton_categorias");
     boton_categorias.onclick=function(){
         console.log("esto");
         containerArea.style.display="none";
         peticionAjaxCtg();
     }
     
     //BORRAR CATEGORIAS 
    
     
     function deleteCategoria(data) {
    fetch(url + '/categoriaDelete', {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-CSRF-TOKEN': csrf
        },
        body: JSON.stringify(data) // Pasar el ID y el nombre en el cuerpo de la solicitud
    }).then(response => {
        return response.json(); // Convertir la respuesta a JSON
    }).then(data => {
        console.log(data); // Manejar la respuesta del servidor aquí
    }).catch(error => {
        console.error('Error al eliminar la categoría:', error);
    });
}

    //  peticionAjaxCtg
     
     function mostrarCatg(productos) {
    let contentDiv = document.getElementById("content");
    contentDiv.innerHTML = '';
    contentDiv.classList.add('table-responsive');
    contentDiv.classList.add('small');

    let table = document.createElement("table");
    table.classList.add('table');
    table.classList.add('table-striped');
    table.classList.add('table-sm');

    let head = document.createElement("thead");
    let thtr = document.createElement("tr");

    let nombre = document.createElement("th");
    nombre.setAttribute("scope", "col");
    nombre.innerHTML = 'Nombre';
    thtr.appendChild(nombre);

    let acciones = document.createElement("th");
    acciones.setAttribute("scope", "col");
    acciones.innerHTML = 'Acciones';
    thtr.appendChild(acciones);

    head.appendChild(thtr);
    table.appendChild(head);

    let body = document.createElement("tbody");

    productos.categorias.forEach(producto => {
        let row = document.createElement('tr');
     console.log(producto.id);
        let nombreCell = document.createElement('td');
        nombreCell.innerHTML = producto.nombre;
        row.appendChild(nombreCell);

        let accionesCell = document.createElement('td');

        let editarBtn = document.createElement('button');
        editarBtn.innerHTML = 'Editar';
        editarBtn.classList.add('btn');
        editarBtn.classList.add('btn-primary');
        editarBtn.id="btnEditCatg"
        editarBtn.style.marginRight = '5px';
        // Agrega aquí el evento para editar
       
        accionesCell.appendChild(editarBtn);

        let borrarBtn = document.createElement('button');
        borrarBtn.innerHTML = 'Borrar';
        borrarBtn.classList.add('btn');
        borrarBtn.classList.add('btn-danger');
        borrarBtn.id="btnDeleteCatg"
       
         borrarBtn.onclick = function() {
    console.log("borrar");
    let data = {
        id: producto.id,
        nombre: producto.nombre
    };
    
    deleteCategoria(data).then(() => {
        
        let contentDiv = document.getElementById("content");
        contentDiv.innerHTML = "";
        peticionAjaxCtg();
    }).catch(error => {
        console.error('Error al borrar la categoría:', error);
    });
}
        accionesCell.appendChild(borrarBtn);

        row.appendChild(accionesCell);

        body.appendChild(row);
    });

    table.appendChild(body);
    contentDiv.appendChild(table);
}



     
     
     //Mostrar productos
     var boton_productos = document.getElementById("boton_productos");
     boton_productos.onclick=function(){
         peticionAjax();
         
     }
 function peticionEditar(data){
     
     
		console.log(data);
		fetch(url + "/producto/"+ data.id, {
			method: 'PUT',
			headers: {
				'Content-Type': 'application/json',
				'Accept': 'application/json',
				'X-CSRF-TOKEN': csrf
			},
			body: JSON.stringify(data),
		})
			.then(response => response.json())
			.then(data => {
				//Eror cuando pone nombre duplicado
				if (data.result > 0) {
				console.log(data);
				
				}
				let ModalEdit= document.getElementById("ModalParaEditar");
            ModalEdit.style.zIndex=-2;
            let ModalEdites= document.getElementById("editModal");
            ModalEdites.style.zIndex=-9;
				console.log(data);
			})
			.catch(error => console.error("Error:", error));
	

 }
 
 
var editProductoModal = document.getElementById('editModal');
 console.log(editProductoModal);
	

  
  
 function mostrarProductos(productos) {
    let contentDiv = document.getElementById("content");
    contentDiv.innerHTML = '';
    contentDiv.classList.add('table-responsive');
    contentDiv.classList.add('small');
    
    let table = document.createElement("table");
    table.classList.add('table');
    table.classList.add('table-striped');
    table.classList.add('table-sm');

    let head = document.createElement("thead");
    let thtr = document.createElement("tr");

    let idCategoria = document.createElement("th");
    idCategoria.setAttribute("scope", "col");
    idCategoria.classList.add('table-dark');
    idCategoria.classList.add('text-center'); // Alinea el texto al centro
    idCategoria.classList.add('text-black'); // Cambia el color del texto a negro
    idCategoria.innerHTML = 'ID Categoría';
    thtr.appendChild(idCategoria);

    let nombre = document.createElement("th");
    nombre.setAttribute("scope", "col");
    nombre.classList.add('table-dark');
    nombre.classList.add('text-center'); // Alinea el texto al centro
    nombre.classList.add('text-black'); // Cambia el color del texto a negro
    nombre.innerHTML = 'Nombre';
    thtr.appendChild(nombre);

    let precio = document.createElement("th");
    precio.setAttribute("scope", "col");
    precio.classList.add('table-dark');
    precio.classList.add('text-center'); // Alinea el texto al centro
    precio.classList.add('text-black'); // Cambia el color del texto a negro
    precio.innerHTML = 'Precio';
    thtr.appendChild(precio);

    let descripcion = document.createElement("th");
    descripcion.setAttribute("scope", "col");
    descripcion.classList.add('table-dark');
    descripcion.classList.add('text-center'); // Alinea el texto al centro
    descripcion.classList.add('text-black'); // Cambia el color del texto a negro
    descripcion.innerHTML = 'Descripción';
    thtr.appendChild(descripcion);

    let acciones = document.createElement("th");
    acciones.setAttribute("scope", "col");
    acciones.classList.add('table-dark');
    acciones.classList.add('text-center'); // Alinea el texto al centro
    acciones.classList.add('text-black'); // Cambia el color del texto a negro
    acciones.innerHTML = 'Acciones';
    thtr.appendChild(acciones);

    head.appendChild(thtr);
    table.appendChild(head);

    let body = document.createElement("tbody");

    productos.producto.forEach(producto => {
        let row = document.createElement('tr');

        let idCategoriaCell = document.createElement('td');
        idCategoriaCell.innerHTML = producto.idcategoria;
        idCategoriaCell.classList.add('text-center'); // Alinea el texto al centro
        idCategoriaCell.classList.add('text-black'); // Cambia el color del texto a negro
        row.appendChild(idCategoriaCell);

        let nombreCell = document.createElement('td');
        nombreCell.innerHTML = producto.nombre;
        nombreCell.classList.add('text-center'); // Alinea el texto al centro
        nombreCell.classList.add('text-black'); // Cambia el color del texto a negro
        row.appendChild(nombreCell);

        let precioCell = document.createElement('td');
        precioCell.innerHTML = producto.precio;
        precioCell.classList.add('text-center'); // Alinea el texto al centro
        precioCell.classList.add('text-black'); // Cambia el color del texto a negro
        row.appendChild(precioCell);

        let descripcionCell = document.createElement('td');
        descripcionCell.innerHTML = producto.descripcion;
        descripcionCell.classList.add('text-center'); // Alinea el texto al centro
        descripcionCell.classList.add('text-black'); // Cambia el color del texto a negro
        row.appendChild(descripcionCell);

        let accionesCell = document.createElement('td');
        accionesCell.classList.add('text-center'); // Alinea el texto al centro
        accionesCell.classList.add('text-black'); // Cambia el color del texto a negro

        let btnedit = document.createElement('a');
        btnedit.className = 'btn btn-outline-warning m-2';
        btnedit.setAttribute('data-bs-toggle', 'modal');
        btnedit.setAttribute('data-bs-target', '#editModal');
        btnedit.setAttribute('data-id', producto.id);
        btnedit.innerHTML = 'Editar';
        btnedit.setAttribute('data-idCategoria', producto.idcategoria);
       btnedit.setAttribute('data-nombre', producto.nombre);
       btnedit.setAttribute('data-precio', producto.precio);
       btnedit.setAttribute('data-descripcion', producto.descripcion);
        
            
        btnedit.addEventListener('click',function(){
            let ModalEdit= document.getElementById("ModalParaEditar");
            ModalEdit.style.zIndex=-2;
            let ModalEdites= document.getElementById("editModal");
            ModalEdites.style.zIndex=1;
//  		let idCategory = document.getElementById('categoriaEdit');
//  		idCategory.value= producto.idcategoria;
	
        let nombre = document.getElementById('nombreEdit');
		nombre.value=producto.nombre;
        
        let precio = document.getElementById('precioEdit');
		precio.value=producto.precio;
        
        let descripcion = document.getElementById('descripcionEdit');
		descripcion.value=producto.descripcion;
        
        
         let BotonEditar= document.getElementById("guardarCambios");
         
        
         
      BotonEditar.onclick=function(){
                
        // let title = document.getElementById('categoriaEdit');
 	
	
        let nombre = document.getElementById('nombreEdit');
	
        
        let precio = document.getElementById('precioEdit');
		
        let descripcion = document.getElementById('descripcionEdit');
		
        
     
        
                console.log()
            let data = {
                "id":producto.id,
                // "idCategoria":title.value,
                "nombre":nombre.value,
                "precio":precio.value,
                "descripcion":descripcion.value
            }
            
            peticionEditar(data);
            document.getElementById("editModal").style.display="none";
        }
        })
        
        accionesCell.appendChild(btnedit);

        let borrarBtn = document.createElement('button');
        borrarBtn.innerHTML = 'Borrar';
        borrarBtn.classList.add('btn');
        borrarBtn.classList.add('btn-danger');
        borrarBtn.id = "btn_deteletProducto";

        borrarBtn.onclick = function () {
            console.log("borrar");
            let data = {
                id: producto.id
            };

            deleteProducto(data).then(() => {

                let contentDiv = document.getElementById("content");
                contentDiv.innerHTML = "";
                peticionAjaxCtg();
            }).catch(error => {
                console.error('Error al borrar el producto:', error);
            });
        }

        accionesCell.appendChild(borrarBtn);

        row.appendChild(accionesCell);

        body.appendChild(row);
    });
    //FIN BUCLE PRODUCTOS

    table.appendChild(body);
    contentDiv.appendChild(table);
}





      
})()